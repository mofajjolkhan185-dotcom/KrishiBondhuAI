package com.krishibondhu.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Leaf = Color(0xFF176B36)
private val Pale = Color(0xFFEAF5EC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KrishiApp() }
    }
}

@Composable
fun KrishiApp() {
    var page by remember { mutableStateOf("home") }
    var selected by remember { mutableStateOf("ধান") }
    var question by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("") }
    var photoChosen by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) {
        photoChosen = it != null
        if (it != null) {
            answer = "ছবি নির্বাচন হয়েছে। AI রোগ বিশ্লেষণ চালু করতে নিরাপদ সার্ভার সংযোগ প্রয়োজন। আপাতত ছবিটি স্থানীয়ভাবে নির্বাচন করা হয়েছে; রোগ নিশ্চিত করা হয়নি।"
            page = "diagnose"
        }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Leaf, secondary = Color(0xFF70A84B), background = Color(0xFFF7FAF7))) {
        Scaffold(
            containerColor = Color(0xFFF7FAF7),
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("কৃষি বন্ধু AI", fontWeight = FontWeight.Bold, color = Color.White)
                            Text("স্মার্ট কৃষি • সমৃদ্ধ খামার", fontSize = 11.sp, color = Color.White.copy(alpha=.85f))
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Leaf),
                    actions = { IconButton(onClick = { page = "help" }) { Icon(Icons.Default.Info, null, tint=Color.White) } }
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    listOf("home" to "হোম", "learn" to "শিখুন", "diagnose" to "রোগ দেখুন", "account" to "আমার").forEach { (key, label) ->
                        NavigationBarItem(
                            selected = page == key,
                            onClick = { page = key },
                            icon = { Icon(when(key) { "home" -> Icons.Default.Home; "learn" -> Icons.Default.MenuBook; "diagnose" -> Icons.Default.PhotoCamera; else -> Icons.Default.Person }, null) },
                            label = { Text(label) }
                        )
                    }
                }
            }
        ) { pad ->
            when(page) {
                "home" -> HomeScreen(Modifier.padding(pad), onOpen={ page=it }, onPhoto={ picker.launch("image/*") })
                "learn" -> LearnScreen(Modifier.padding(pad), onSelect={ selected=it; page="topic" })
                "topic" -> TopicScreen(Modifier.padding(pad), selected, onBack={page="learn"})
                "diagnose" -> DiagnoseScreen(Modifier.padding(pad), question, {question=it}, answer, { answer = "আপনার প্রশ্নটি লেখা হয়েছে। AI উত্তর চালু করতে সার্ভার/API সংযোগ প্রয়োজন। জরুরি রোগে স্থানীয় প্রাণিসম্পদ বা কৃষি কর্মকর্তার পরামর্শ নিন।" }, {picker.launch("image/*")})
                "account" -> AccountScreen(Modifier.padding(pad))
                else -> HelpScreen(Modifier.padding(pad), onBack={page="home"})
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(modifier: Modifier, onOpen:(String)->Unit, onPhoto:()->Unit) {
    LazyColumn(modifier.fillMaxSize().padding(horizontal=16.dp), verticalArrangement=Arrangement.spacedBy(14.dp), contentPadding=PaddingValues(vertical=16.dp)) {
        item {
            Card(colors=CardDefaults.cardColors(containerColor=Leaf), shape=RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(20.dp)) {
                    Text("আসসালামু আলাইকুম 👋", color=Color.White.copy(alpha=.9f))
                    Text("আপনার খামার ও ফসলের\nযত্নে পাশে আছে কৃষি বন্ধু", color=Color.White, fontSize=23.sp, fontWeight=FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("সহজ বাংলায় কৃষি ও পশুপালন পরামর্শ", color=Color.White.copy(alpha=.9f))
                }
            }
        }
        item { Text("আপনি কী জানতে চান?", fontSize=18.sp, fontWeight=FontWeight.Bold) }
        item {
            val tiles = listOf("🌾" to "ফসল ও কৃষি", "🌱" to "গাছের যত্ন", "🐄" to "গরু পালন", "🐐" to "ছাগল পালন", "🐔" to "হাঁস-মুরগি", "🐟" to "মাছ চাষ", "💉" to "টিকা ও স্বাস্থ্য", "📊" to "খামারের হিসাব")
            Column(verticalArrangement=Arrangement.spacedBy(10.dp)) {
                tiles.chunked(2).forEach { pair ->
                    Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                        pair.forEach { (emoji, title) ->
                            Card(Modifier.weight(1f).clickable { onOpen("learn") }, colors=CardDefaults.cardColors(containerColor=Color.White), shape=RoundedCornerShape(16.dp)) {
                                Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment=Alignment.CenterHorizontally) {
                                    Text(emoji, fontSize=28.sp)
                                    Text(title, fontWeight=FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                }
            }
        }
        item {
            Card(colors=CardDefaults.cardColors(containerColor=Pale), shape=RoundedCornerShape(18.dp)) {
                Row(Modifier.fillMaxWidth().clickable { onPhoto() }.padding(16.dp), verticalAlignment=Alignment.CenterVertically) {
                    Icon(Icons.Default.CameraAlt, null, tint=Leaf, modifier=Modifier.size(34.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("ছবি দিয়ে সমস্যা জানান", fontWeight=FontWeight.Bold, color=Leaf)
                        Text("গাছ, পাতা বা পশুপাখির ছবি নির্বাচন করুন", fontSize=12.sp)
                    }
                    Icon(Icons.Default.ArrowForward, null, tint=Leaf)
                }
            }
        }
        item { Text("পরামর্শ: রোগের লক্ষণ, বয়স ও আক্রান্তের সংখ্যা লিখলে বিশেষজ্ঞকে বোঝানো সহজ হয়।", color=Color.Gray, fontSize=12.sp) }
    }
}

@Composable
fun LearnScreen(modifier: Modifier, onSelect:(String)->Unit) {
    val topics = listOf("ধান চাষ","গম চাষ","ভুট্টা ও সবজি","ফলের গাছ","গাছের রোগ ও পোকা","গরু পালন","ছাগল পালন","ব্রয়লার মুরগি","লেয়ার মুরগি","হাঁস পালন","মাছ চাষ","টিকা ও খামারের স্বাস্থ্যবিধি")
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("কৃষি জ্ঞানভান্ডার", fontSize=22.sp, fontWeight=FontWeight.Bold)
        Text("বিষয় নির্বাচন করে প্রাথমিক নির্দেশনা দেখুন", color=Color.Gray)
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            items(topics) { t ->
                Card(Modifier.fillMaxWidth().clickable { onSelect(t) }, colors=CardDefaults.cardColors(containerColor=Color.White)) {
                    Row(Modifier.padding(16.dp), verticalAlignment=Alignment.CenterVertically) {
                        Icon(Icons.Default.Spa, null, tint=Leaf)
                        Spacer(Modifier.width(12.dp))
                        Text(t, Modifier.weight(1f), fontWeight=FontWeight.Medium)
                        Icon(Icons.Default.ChevronRight, null)
                    }
                }
            }
        }
    }
}

@Composable
fun TopicScreen(modifier: Modifier, topic:String, onBack:()->Unit) {
    Column(modifier.fillMaxSize().padding(20.dp)) {
        TextButton(onClick=onBack) { Text("← ফিরে যান") }
        Text(topic, fontSize=24.sp, fontWeight=FontWeight.Bold, color=Leaf)
        Spacer(Modifier.height(12.dp))
        Text("এই বিভাগে থাকবে:", fontWeight=FontWeight.Bold)
        listOf("পরিচিতি ও উপযুক্ত জাত", "জমি/ঘর প্রস্তুতি", "খাদ্য, সার ও পরিচর্যা", "রোগের লক্ষণ ও প্রতিরোধ", "প্রয়োজনীয় সময়সূচি").forEach {
            Row(Modifier.padding(vertical=8.dp), verticalAlignment=Alignment.CenterVertically) {
                Icon(Icons.Default.CheckCircle, null, tint=Leaf)
                Spacer(Modifier.width(8.dp)); Text(it)
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("এটি প্রাথমিক অ্যাপ কাঠামো। নির্ভুল স্থানীয় নির্দেশনা ও যাচাইকৃত কনটেন্ট যুক্ত করার কাজ পরবর্তী ধাপ।", color=Color.Gray)
    }
}

@Composable
fun DiagnoseScreen(modifier: Modifier, question:String, onQuestion:(String)->Unit, answer:String, onAsk:()->Unit, onPhoto:()->Unit) {
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Text("AI কৃষি সহকারী", fontSize=22.sp, fontWeight=FontWeight.Bold)
        Text("সমস্যার বিবরণ লিখুন অথবা ছবি নির্বাচন করুন।", color=Color.Gray)
        OutlinedTextField(question, onQuestion, Modifier.fillMaxWidth(), label={Text("আপনার সমস্যা লিখুন")}, minLines=3)
        Button(onClick=onAsk, modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.Send, null); Spacer(Modifier.width(8.dp)); Text("পরামর্শ চাই") }
        OutlinedButton(onClick=onPhoto, modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.AddAPhoto, null); Spacer(Modifier.width(8.dp)); Text("ছবি নির্বাচন করুন") }
        if(answer.isNotBlank()) Card(colors=CardDefaults.cardColors(containerColor=Pale)) { Text(answer, Modifier.padding(16.dp)) }
        Spacer(Modifier.height(8.dp))
        Text("সতর্কতা: এই প্রাথমিক সংস্করণে AI বিশ্লেষণ এখনো সংযুক্ত নয়। গুরুতর অসুস্থতা বা দ্রুত ছড়ানো রোগে সরাসরি কৃষি/প্রাণিসম্পদ কর্মকর্তার সাহায্য নিন।", color=Color(0xFF8A4B00), fontSize=12.sp)
    }
}

@Composable
fun AccountScreen(modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
        Text("আমার খামার", fontSize=22.sp, fontWeight=FontWeight.Bold)
        Text("এই সংস্করণে ব্যক্তিগত খামারের তথ্য স্থানীয়ভাবে সংরক্ষণ/সিঙ্ক করার সুবিধা এখনো যুক্ত হয়নি।")
        listOf("আমার ফসলের তালিকা","পশুপাখির সংখ্যা","টিকা ও পরিচর্যার রিমাইন্ডার","আয়-ব্যয়ের হিসাব").forEach {
            ListItem(headlineContent={Text(it)}, leadingContent={Icon(Icons.Default.Folder, null, tint=Leaf)})
        }
    }
}

@Composable
fun HelpScreen(modifier: Modifier, onBack:()->Unit) {
    Column(modifier.fillMaxSize().padding(20.dp)) {
        TextButton(onClick=onBack) { Text("← হোমে ফিরুন") }
        Text("সহায়তা ও নিরাপত্তা", fontSize=22.sp, fontWeight=FontWeight.Bold)
        Text("কৃষি বন্ধু AI শিক্ষামূলক সহায়তার জন্য। রোগ নির্ণয় বা চিকিৎসার চূড়ান্ত সিদ্ধান্ত হিসেবে ব্যবহার করবেন না। ওষুধের মাত্রা, অ্যান্টিবায়োটিক বা কীটনাশক ব্যবহারের আগে নিবন্ধিত/সরকারি বিশেষজ্ঞের পরামর্শ নিন।")
    }
}
